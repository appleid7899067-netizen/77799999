import { createFileRoute } from "@tanstack/react-router";
import {
  Bot,
  Code2,
  FileText,
  Globe,
  Loader2,
  Pin,
  Plus,
  Send,
  Sparkles,
  Trash2,
} from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { MarkdownOutput } from "@/components/markdown-output";
import { ModelPicker } from "@/components/pickers";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { runFleet } from "@/lib/ai";
import { AGENTS, MCP_SERVERS, modelById } from "@/lib/catalog";
import { useFleet } from "@/lib/store";

export const Route = createFileRoute("/chat")({ component: ChatPage });

function ChatPage() {
  const threads = useFleet((s) => s.threads);
  const activeThreadId = useFleet((s) => s.activeThreadId);
  const newThread = useFleet((s) => s.newThread);
  const setActiveThread = useFleet((s) => s.setActiveThread);
  const pinThread = useFleet((s) => s.pinThread);
  const deleteThread = useFleet((s) => s.deleteThread);
  const appendMessage = useFleet((s) => s.appendMessage);
  const updateTools = useFleet((s) => s.updateTools);
  const toggleMcp = useFleet((s) => s.toggleMcp);
  const spend = useFleet((s) => s.spend);
  const addCredits = useFleet((s) => s.addCredits);
  const modelId = useFleet((s) => s.modelId);
  const memory = useFleet((s) => s.memory);

  const thread = threads.find((t) => t.id === activeThreadId) ?? threads[0];
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const scroller = useRef<HTMLDivElement>(null);

  const sorted = useMemo(
    () =>
      [...threads].sort((a, b) => {
        if (a.pinned && !b.pinned) return -1;
        if (!a.pinned && b.pinned) return 1;
        return b.updatedAt - a.updatedAt;
      }),
    [threads],
  );

  async function send() {
    if (!thread || !draft.trim() || busy) return;
    const text = draft.trim();
    setDraft("");
    const model = modelById(modelId);
    const cost = thread.tools.agents ? Math.max(2, model.credits) : model.credits || 1;
    if (!spend(cost)) {
      toast.error("Out of credits — topping up the prototype balance.");
      addCredits(20);
      return;
    }
    appendMessage(thread.id, { role: "user", content: text });
    setBusy(true);
    const activity: string[] = [];
    if (thread.tools.web) activity.push("Web");
    if (thread.tools.code) activity.push("Code exec");
    if (thread.tools.files) activity.push("Files");
    if (thread.tools.agents) activity.push("Agents ×" + AGENTS.length);
    thread.mcp.forEach((m) => activity.push("MCP " + m));

    try {
      const history = thread.messages
        .slice(-8)
        .map((m) => `${m.role}: ${m.content}`)
        .join("\n\n");
      const extras = [
        `Active tools: ${JSON.stringify(thread.tools)}`,
        thread.mcp.length ? `MCP: ${thread.mcp.join(", ")}` : "",
        memory.length ? `Memory: ${memory.map((m) => m.text).join("; ")}` : "",
        history ? `Recent thread:\n${history}` : "",
      ]
        .filter(Boolean)
        .join("\n");

      const res = await runFleet({
        data: {
          mode: thread.tools.agents ? "agents" : "chat",
          prompt: text,
          modelId,
          extras,
        },
      });
      if (!res.ok) {
        toast.error(res.error);
        addCredits(cost);
        appendMessage(thread.id, {
          role: "assistant",
          content: `Could not complete that turn.\n\n${res.error}`,
          activity,
        });
        return;
      }
      appendMessage(thread.id, {
        role: "assistant",
        content: res.text,
        model: res.model,
        activity,
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Chat failed");
      addCredits(cost);
    } finally {
      setBusy(false);
      requestAnimationFrame(() => {
        scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
      });
    }
  }

  if (!thread) return null;

  return (
    <AppShell>
      <div className="mx-auto flex h-[calc(100dvh-3.5rem)] max-w-6xl">
        <aside className="hidden w-64 shrink-0 flex-col border-r border-border md:flex">
          <div className="flex items-center justify-between p-3">
            <p className="text-xs font-medium uppercase tracking-wider text-subtle">Chats</p>
            <Button size="icon-sm" variant="ghost" aria-label="New chat" onClick={() => newThread()}>
              <Plus className="size-4" />
            </Button>
          </div>
          <ScrollArea className="flex-1">
            <div className="space-y-0.5 px-2 pb-4">
              {sorted.map((t) => (
                <div
                  key={t.id}
                  className={`group flex items-center gap-1 rounded-md px-2 py-2 text-left text-sm ${
                    t.id === thread.id ? "bg-elevated text-fg" : "text-muted hover:bg-elevated/60 hover:text-fg"
                  }`}
                >
                  <button type="button" className="min-w-0 flex-1 truncate text-left" onClick={() => setActiveThread(t.id)}>
                    {t.pinned ? "· " : ""}
                    {t.title}
                  </button>
                  <button
                    type="button"
                    className="hidden size-7 items-center justify-center rounded-sm group-hover:flex hover:bg-bg"
                    onClick={() => pinThread(t.id)}
                    aria-label="Pin"
                  >
                    <Pin className="size-3.5" />
                  </button>
                  <button
                    type="button"
                    className="hidden size-7 items-center justify-center rounded-sm text-subtle group-hover:flex hover:text-danger"
                    onClick={() => deleteThread(t.id)}
                    aria-label="Delete"
                  >
                    <Trash2 className="size-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </ScrollArea>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <div className="flex flex-wrap items-center gap-2 border-b border-border px-3 py-2">
            <ModelPicker compact />
            <div className="ml-auto flex items-center gap-1 md:hidden">
              <Button size="icon-sm" variant="ghost" onClick={() => newThread()} aria-label="New chat">
                <Plus className="size-4" />
              </Button>
            </div>
          </div>

          <div ref={scroller} className="flex-1 overflow-y-auto px-4 py-6">
            <div className="mx-auto max-w-2xl space-y-5">
              {thread.messages.map((m) => (
                <div key={m.id} className={m.role === "user" ? "ml-8" : "mr-4"}>
                  <p className="mb-1 text-[11px] uppercase tracking-wider text-subtle">
                    {m.role === "user" ? "You" : "Fleet"}
                    {m.model ? ` · ${m.model}` : ""}
                  </p>
                  {m.activity && m.activity.length > 0 && (
                    <div className="mb-2 flex flex-wrap gap-1">
                      {m.activity.map((a) => (
                        <Badge key={a}>{a}</Badge>
                      ))}
                    </div>
                  )}
                  <div
                    className={
                      m.role === "user"
                        ? "rounded-lg bg-elevated px-3 py-2 text-sm shadow-[var(--shadow-border)]"
                        : ""
                    }
                  >
                    {m.role === "assistant" ? (
                      <MarkdownOutput text={m.content} />
                    ) : (
                      <p className="whitespace-pre-wrap">{m.content}</p>
                    )}
                  </div>
                </div>
              ))}
              {busy && (
                <div className="flex items-center gap-2 text-sm text-muted">
                  <Loader2 className="size-4 animate-spin text-primary" />
                  {thread.tools.agents ? "Agents running in parallel…" : "Thinking…"}
                </div>
              )}
            </div>
          </div>

          <div className="border-t border-border px-3 py-3">
            <div className="mx-auto max-w-2xl">
              <div className="mb-2 flex flex-wrap gap-3">
                <ToolToggle
                  icon={Globe}
                  label="Web"
                  on={thread.tools.web}
                  onChange={(v) => updateTools(thread.id, { ...thread.tools, web: v })}
                />
                <ToolToggle
                  icon={Code2}
                  label="Code"
                  on={thread.tools.code}
                  onChange={(v) => updateTools(thread.id, { ...thread.tools, code: v })}
                />
                <ToolToggle
                  icon={FileText}
                  label="Files"
                  on={thread.tools.files}
                  onChange={(v) => updateTools(thread.id, { ...thread.tools, files: v })}
                />
                <ToolToggle
                  icon={Bot}
                  label="Agents"
                  on={thread.tools.agents}
                  onChange={(v) => updateTools(thread.id, { ...thread.tools, agents: v })}
                />
              </div>
              <div className="mb-2 flex flex-wrap gap-1">
                {MCP_SERVERS.slice(0, 8).map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => toggleMcp(thread.id, s.id)}
                    className={`rounded-full px-2 py-0.5 text-[11px] ${
                      thread.mcp.includes(s.id)
                        ? "bg-primary/15 text-primary"
                        : "bg-elevated text-subtle"
                    }`}
                  >
                    {s.name}
                  </button>
                ))}
              </div>
              <div className="flex items-end gap-2 rounded-lg bg-elevated p-2 shadow-[var(--shadow-border)]">
                <Textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      void send();
                    }
                  }}
                  placeholder="Ask the fleet…  Shift+Enter for a newline"
                  className="min-h-12 border-0 bg-transparent shadow-none focus-visible:shadow-none"
                  rows={2}
                />
                <Button size="icon" onClick={() => void send()} disabled={busy || !draft.trim()} aria-label="Send">
                  {busy ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
                </Button>
              </div>
              <p className="mt-2 flex items-center gap-1 text-[11px] text-subtle">
                <Sparkles className="size-3" />
                Enter send · Shift+Enter newline
              </p>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function ToolToggle({
  icon: Icon,
  label,
  on,
  onChange,
}: {
  icon: typeof Globe;
  label: string;
  on: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <label className="flex items-center gap-1.5 text-xs text-muted">
      <Icon className="size-3.5 text-primary" />
      {label}
      <Switch checked={on} onCheckedChange={onChange} />
    </label>
  );
}
